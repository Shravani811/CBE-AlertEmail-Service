package alertMailService;

public class EventEntry {

	private Long eventID;
private String eventName;
private String startDate;
private String endDate;
private String additionalReceipients;
private String recurrenceType;
//added for Daily Recurrence
private String recuEveryWeekday;
private String recuEveryDay;

//added for Weekly Recurrence
private String recurrenceDayName;
private String recuEveryWeek;

//added for Monthly Recurrence
private String recuMonthDay;
private String recuEveryMonth;
private String eventDesc;
private String attachment;


private String monthdd1;
private String monthdd2;
private String monthtext1;
private String recuMonthDayRadio;
public Long getEventID() {
	return eventID;
}
public void setEventID(Long eventID) {
	this.eventID = eventID;
}
public String getEventName() {
	return eventName;
}
public void setEventName(String eventName) {
	this.eventName = eventName;
}
public String getStartDate() {
	return startDate;
}
public void setStartDate(String startDate) {
	this.startDate = startDate;
}
public String getEndDate() {
	return endDate;
}
public void setEndDate(String endDate) {
	this.endDate = endDate;
}
public String getAdditionalReceipients() {
	return additionalReceipients;
}
public void setAdditionalReceipients(String additionalReceipients) {
	this.additionalReceipients = additionalReceipients;
}
public String getRecurrenceType() {
	return recurrenceType;
}
public void setRecurrenceType(String recurrenceType) {
	this.recurrenceType = recurrenceType;
}
public String getRecuEveryWeekday() {
	return recuEveryWeekday;
}
public void setRecuEveryWeekday(String recuEveryWeekday) {
	this.recuEveryWeekday = recuEveryWeekday;
}
public String getRecuEveryDay() {
	return recuEveryDay;
}
public void setRecuEveryDay(String recuEveryDay) {
	this.recuEveryDay = recuEveryDay;
}
public String getRecurrenceDayName() {
	return recurrenceDayName;
}
public void setRecurrenceDayName(String recurrenceDayName) {
	this.recurrenceDayName = recurrenceDayName;
}
public String getRecuEveryWeek() {
	return recuEveryWeek;
}
public void setRecuEveryWeek(String recuEveryWeek) {
	this.recuEveryWeek = recuEveryWeek;
}
public String getRecuMonthDay() {
	return recuMonthDay;
}
public void setRecuMonthDay(String recuMonthDay) {
	this.recuMonthDay = recuMonthDay;
}
public String getRecuEveryMonth() {
	return recuEveryMonth;
}
public void setRecuEveryMonth(String recuEveryMonth) {
	this.recuEveryMonth = recuEveryMonth;
}
public String getMonthdd1() {
	return monthdd1;
}
public void setMonthdd1(String monthdd1) {
	this.monthdd1 = monthdd1;
}
public String getMonthdd2() {
	return monthdd2;
}
public void setMonthdd2(String monthdd2) {
	this.monthdd2 = monthdd2;
}
public String getMonthtext1() {
	return monthtext1;
}
public void setMonthtext1(String monthtext1) {
	this.monthtext1 = monthtext1;
}
public String getRecuMonthDayRadio() {
	return recuMonthDayRadio;
}
public void setRecuMonthDayRadio(String recuMonthDayRadio) {
	this.recuMonthDayRadio = recuMonthDayRadio;
}
public String getEventDesc() {
	return eventDesc;
}
public void setEventDesc(String eventDesc) {
	this.eventDesc = eventDesc;
}
public String getAttachment() {
	return attachment;
}
public void setAttachment(String attachment) {
	this.attachment = attachment;
}


}
